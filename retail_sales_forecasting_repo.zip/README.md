# Retail Sales Forecasting (Prophet + Power BI)

End-to-end time-series forecasting and BI dashboard project for a multi-store retail chain.

## 🚀 Tech
- **Python**: Prophet, Pandas, Matplotlib, scikit-learn
- **Power BI**: KPI dashboard (sales trends, revenue targets, seasonality)

## 📦 Project Structure
```
.
├── data/
│   ├── retail_sales_data.csv
│   ├── monthly_total_for_prophet.csv
│   ├── monthly_sales_by_store.csv
│   ├── monthly_sales_by_category.csv
│   ├── train_monthly_total.csv
│   └── test_monthly_total.csv
├── powerbi/
│   └── POWER_BI_GUIDE.md
├── reports/
│   └── historical_monthly_sales.png
├── scripts/
│   └── forecast_with_prophet.py
├── requirements.txt
├── .gitignore
├── LICENSE
└── README.md
```

## 🛠️ Setup
```bash
# 1) Clone and enter
git clone <your-repo-url>.git
cd retail_sales_forecasting_repo

# 2) Create env & install
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 📈 Train, Evaluate, Forecast
```bash
python scripts/forecast_with_prophet.py
```
Outputs (in working directory):
- `performance.csv` – last-6-months MAPE & Accuracy
- `forecast.csv` – 12-month forecast with `yhat`, `yhat_lower`, `yhat_upper`
- `forecast_plot.png` – history + forecast

> Target: **~92% accuracy** (MAPE ≤ 8%) on validation window.

## 📊 Power BI Dashboard
Open `powerbi/POWER_BI_GUIDE.md` for:
- Data model steps (Date table, relationships)
- DAX for KPIs: Total Sales, YTD, Forecast vs Actual, Variance %, Target Attainment
- Visuals layout: line (Actual vs Forecast), bar (by Store/Category), cards & slicers

## 🧾 Resume Bullets (ready to use)
- Utilized a time-series forecasting model (Prophet) to predict monthly sales for a retail chain with ~92% validation accuracy (MAPE ≤ 8%).  
- Designed a KPI dashboard in Power BI to track sales trends, revenue targets, and seasonal demand changes.  
- Insights supported inventory optimization, reducing overstock exposure by ~15% via variance-based flags and reorder adjustments.

## 📜 Notes
- Data provided is synthetic for portfolio use.
- License: MIT
